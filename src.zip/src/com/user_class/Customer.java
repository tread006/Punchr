package com.user_class;

public class Customer extends User {
	
	String custID;
	int numberofpunches;
	int bday;			//MMDDYYYY
	String address;
	boolean optin;		//agree or disagree (true or false)
	String preference;	//Breakfast, lunch or both
	

	Customer(String cid, int numberofpunches, int bday, String address, boolean optin, String preference, String email, String fname, String lname, int password) {
		super (email, fname, lname, password);
		custID = cid;
	}
	
	
	void printCustomerDetails() {
	    System.out.println("Customer email:    " + email);
	    System.out.println("Customer first name:    " + fname);
	    System.out.println("Customer last name:    " + lname);	   
	    
		System.out.println("Customer ID:    " + custID);
	    System.out.println("Number of punche(s):    " + numberofpunches);
	    System.out.println("Birth date:    " + bday);
	    System.out.println("Address:    " + address);
	    System.out.println("Preferences:    " + preference);
	    System.out.println("You agreed that PunchR can collect your data for improvement purposes:    " + optin);

	}


}
