package com.user_class;

public abstract class User { //User class
	
	 String email;
	 String fname;
	 String lname;
	 int password;
	
	
	 User(String email, String fname, String lname, int password) {
		this.email = email;
		this.fname = fname;
		this.lname = lname;
		this.password = password;
	}


	

/*	public static void main(String[] args) {
		 email  = "gaye002@csusm.edu";
		String fname ;
		String lname ;
		int password ;
		System.out.println(email + " " + "Welcome User");

	}*/
	
/*	private String email ;
	private String fname ;
	private String lname ;
	private int password ;
	
	public User(String email, String fname, String lname, int password) {
		this.email = email;
		this.fname = fname;
		this.lname = lname;
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public int getPassword() {
		return password;
	}

	public void setPassword(int password) {
		this.password = password;
	}*/
	

}
