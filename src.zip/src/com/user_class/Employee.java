package com.user_class;

public class Employee extends User {
	
	String empID;
	
	Employee(String eid, String email, String fname, String lname, int password) {
		super (email, fname, lname, password);
		empID = eid;
	}
	
	void printEmployeeDetails() {
	    System.out.println("Employee ID     :  " + empID);
	    
	    System.out.println("Employee email   :  " + email);
	    System.out.println("Employee first name    :  " + fname);
	    System.out.println("Employee last name :  " + lname);
	}



}


