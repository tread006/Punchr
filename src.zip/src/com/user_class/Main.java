package com.user_class;

public class Main {

	public static void main(String[] args) {
		
		Customer a = new Customer("karen01", 3, 12251993, "333 Twin Oaks Valley Rd, 92078 San Marcos, CA", true, "breakfast", "karen01@csusm.edu", "Karen", "Stevenson", 98765);
		a.printCustomerDetails();
		
		Employee b = new Employee("lucie002", "gaye002@csusm.edu", "lucie", "gaye", 12345);
		b.printEmployeeDetails();
		
		/*User user1 = new User();
		System.out.println("email: " + user1.getEmail());
		System.out.println("first name: " + user1.getFname());
		System.out.println("last name: " + user1.getLname());*/

	}

}
